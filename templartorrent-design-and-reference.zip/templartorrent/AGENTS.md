# TemplarTorrent coding-agent contract

## Non-negotiable product constraints

Use Rust, PixelKit, and rbit. Keep Windows and Linux supported. No webview, second GUI
stack, libtorrent wrapper, external torrent process, media player or network content
search. Name the production binary `templartorrent`. Follow DESIGN.md rather than
inventing a broader product. Respect the strict native-source audit gate.

## Starting state

This is an uncompiled design/reference handoff, not a completed client. Core policies,
SIMD and microbench code exist. The GUI is a labeled fixture preview. The rbit adapter
has real API wrappers but no full session loop. There are no compiled/tested binaries,
no real swarm results and no performance baseline. Read the status table first.

## Work in this order

1. Compile/test/format the current root and both integrations on the pinned toolchain;
   correct actual API issues, commit real lockfiles and resolve the dependency audit.
2. Build a deterministic localhost v1 transfer and seed using real rbit networking,
   verified data and bounded memory. Add fault injection, not an imaginary backend.
3. Wire the complete PixelKit workflow and native activation/clipboard; no fixture
   data in live mode. Include limits and safe non-destructive removal first.
4. Complete protected storage/deletion, resume/crash/private-discovery tests, v2/hybrid
   capability gates and offline country/client/peer-preference integration.
5. Establish performance baselines and optimize from evidence, including scalar/AVX2.

## Evidence required in every handoff

State precisely which code paths ran, on which OS/CPU/toolchain, with which fixtures.
Report build/test commands, failures, raw metric artifacts and unresolved risks.
Never label a typed command as implemented merely because a button dispatches it.
Never call a progress timer a torrent download. Disabled functionality needs a visible
reason. Keep all Internet smoke tests opt-in and use explicitly permitted content.

Run unit tests and packet/privacy/storage tests after scheduler or transport changes.
Do not make destructive tests outside newly created owned temporary roots. Do not
leak magnets, infohashes, tracker passkeys or peer IPs in default uploaded logs.

## Performance rules

Retain the dependency-free reference scheduler as an oracle. Use a fake monotonic
clock for rate/backoff/lease tests. Bound queues before improving throughput. Measure
RSS and internal byte ownership separately. Minimized windows must not generate a
continuous redraw loop. No global `target-cpu=native` or AVX2 requirement in shipping
artifacts. Prefer one focused change with an explanation and before/after evidence.

## Completion means

The user can paste/open a magnet, choose a folder, complete and seed an actual
verified transfer, change global slot/speed settings, observe correct details/files/
peers, experience ordered-file promotion, reannounce safely, get public-only tracker
augmentation, and remove a job with the data checkbox behaving safely. Both OSes
must pass; Windows paste and data-handle closure count as functionality, not polish.
